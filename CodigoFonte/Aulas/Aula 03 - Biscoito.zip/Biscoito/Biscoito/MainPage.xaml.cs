﻿namespace Biscoito;

public partial class MainPage : ContentPage
{
	int count = 0;

	public MainPage()
	{
		InitializeComponent();
	}

	private void OnBtnComerClicked(object sender, EventArgs e)
	{
		imgBiscoito.Source = "after_cookie.jpg";
		((Button)sender).IsEnabled = false;
    }
}

