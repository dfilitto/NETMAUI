﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cartao.Models
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public string Instagram { get; }
        public string YouTube { get; }
        public string Whatsapp { get; }

        public Pessoa()
        {
            Nome = "Danilo Filitto";
            Descricao = "Mestre em Ciência da Computação pela Universidade Estadual de Maringá – UEM e Pós-Graduado em Redes de Computadores e Comunicação de Dados pela Universidade do Estado do Paraná – UEL";
            Instagram = "https://www.instagram.com/dfilitto/";
            YouTube = "https://www.youtube.com/@dfilitto";
            Whatsapp = "https://api.whatsapp.com/send?phone=5518996279281";
        }

    }
}
