﻿using Cartao.Models;

namespace Cartao;

public partial class MainPage : ContentPage
{
	
    //Pessoa pessoa = new Pessoa();

	public MainPage()
	{
		InitializeComponent();
		//BindingContext = new Pessoa();
	}

    private async void btnInstagram_Clicked(object sender, EventArgs e)
    {
        if (BindingContext is Models.Pessoa pessoa)
        {
            await Launcher.Default.OpenAsync(pessoa.Instagram);
        }
    }

    private async void btnYouTube_Clicked(object sender, EventArgs e)
    {
        if (BindingContext is Models.Pessoa pessoa)
        {
            await Launcher.Default.OpenAsync(pessoa.YouTube);
        }
    }

    private async void btnWhatsApp_Clicked(object sender, EventArgs e)
    {
        if (BindingContext is Models.Pessoa pessoa)
        {
            await Launcher.Default.OpenAsync(pessoa.Whatsapp);
        }
    }
}

