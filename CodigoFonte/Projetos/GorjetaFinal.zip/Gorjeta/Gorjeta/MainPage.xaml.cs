﻿namespace Gorjeta;

public partial class MainPage : ContentPage
{
	bool isBlack = true;

	public MainPage()
	{
		InitializeComponent();
	}

    private void btnCalcular_Clicked(object sender, EventArgs e)
    {
		double valorConta = Convert.ToDouble(entValorConta.Text);
		double perGorjeta = Convert.ToDouble(entPerGorjeta.Text);
		double valorGorjeta = valorConta * perGorjeta/100;
		double total = valorGorjeta + valorConta;
		//parte de tela
		vslResultado.IsVisible = true;
		lbValorGorjeta.Text = "R$ " + valorGorjeta.ToString("F2");
		lbValorTotal.Text = "R$ " + total.ToString("F2");


    }

	private void ChangeColor(object sender, EventArgs e)
	{
		if (isBlack == true)
		{
            isBlack = false;
            this.Resources["PageColor1"] = Colors.White;
            this.Resources["EntryColor1"] = Colors.Black;
            this.Resources["LabelColor1"] = Colors.Black;
        }
		else
		{
            isBlack = true;
            this.Resources["PageColor1"] = Colors.Black;
            this.Resources["EntryColor1"] = Colors.White;
            this.Resources["LabelColor1"] = Colors.White;
        }
	}
}

