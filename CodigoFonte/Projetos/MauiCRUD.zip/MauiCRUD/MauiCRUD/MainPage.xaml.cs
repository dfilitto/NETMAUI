﻿using SQLite;

namespace MauiCRUD;

public partial class MainPage : ContentPage
{
    string _dbPath; //caminho do banco de dados
    SQLiteConnection conn; //Conexão com o banco Sqlite

	public MainPage()
	{
		InitializeComponent();
	}

    private void CriarBancoDeDadosBtn_Clicked(object sender, EventArgs e)
    {
        //Definir o caminho do banco de dados
        _dbPath = System.IO.Path.Combine(FileSystem.AppDataDirectory, "sites.db3");
        //criar o banco de dados
        conn = new SQLiteConnection(_dbPath);
        conn.CreateTable<Site>();
        OperacoesVsl.IsVisible = true;

    }

    private void InserirBtn_Clicked(object sender, EventArgs e)
    {
        Site site = new Site();
        site.Endereco = ValorEnt.Text;
        conn.Insert(site);
        ValorEnt.Text = "";
        IdEnt.Text = "";
        LimparCampos();
        ListarSites();
    }

    private void AlterarBtn_Clicked(object sender, EventArgs e)
    {
        Site site = new Site();
        site.Id = Convert.ToInt32(IdEnt.Text);
        site.Endereco = ValorEnt.Text;
        conn.Update(site);
        LimparCampos();
        ListarSites();
    }

    private void ExcluirBtn_Clicked(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(IdEnt.Text);
        conn.Delete<Site>(id);
        LimparCampos();
        ListarSites();
    }

    private void LocalizarBtn_Clicked(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(IdEnt.Text);
        var sites = from s in conn.Table<Site>()
                    where s.Id == id
                    select s;

        Site site = sites.First();
        IdEnt.Text = site.Id.ToString();
        ValorEnt.Text = site.Endereco;
    }

    private void ListarBtn_Clicked(object sender, EventArgs e)
    {
        LimparCampos();
        ListarSites();
    }

    public void ListarSites()
    {
        List<Site> lista = conn.Table<Site>().ToList();
        ListaCv.ItemsSource = lista;
    }

    public void LimparCampos()
    {
        IdEnt.Text = "";
        ValorEnt.Text = "";
    }

    private async void OnWebsiteLabelTapped(object sender, EventArgs e)
    {
        var label = sender as Label;
        if (label != null && label.BindingContext is Site item)
        {
            var websiteUrl = "https://"+item.Endereco.ToString();
            await Launcher.OpenAsync(new Uri(websiteUrl));
        }
    }

    private void TapGestureAlterarSite(object sender, TappedEventArgs e)
    {
        var label = sender as Label;
        if (label != null && label.BindingContext is Site item)
        {
            IdEnt.Text = item.Id.ToString();
            ValorEnt.Text = item.Endereco;
        }
    }
}

